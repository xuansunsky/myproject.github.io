package com.itheima.service;

import com.itheima.pojo.StudentAnalysis;

public interface AnalysisService {
    void add(StudentAnalysis studentAnalysis);
    StudentAnalysis getstate(Integer sid);
    StudentAnalysis get(Integer id);

    void update(Integer id);

    void delete(Integer id);
}
