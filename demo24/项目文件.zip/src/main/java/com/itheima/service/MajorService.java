package com.itheima.service;

import com.itheima.pojo.Major;

import java.util.List;

public interface MajorService {
    List<Major> get(Integer id);

    Major createMajor(Major major);

    Major updateMajor(Major major);

    void deleteMajor(Integer id);
}
