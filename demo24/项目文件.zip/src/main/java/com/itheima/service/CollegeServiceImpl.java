package com.itheima.service;

import com.itheima.mapper.CollegeMapper;
import com.itheima.pojo.College;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CollegeServiceImpl implements CollegeService{
    @Autowired
    private CollegeMapper collegeMapper;
    @Override
    public College getColleges(Integer id) {
        return collegeMapper.getColleges(id);
    }

    public College createCollege(College college) {
        collegeMapper.insert(college);
        return college;
    }

    public College updateCollege(College college) {

        collegeMapper.update(college);
        return college;
    }

    public void deleteCollege(Integer id) {
        collegeMapper.delete(id);
    }

    @Override
    public List<College> getallcolleges() {

        return collegeMapper.getallcollege();
    }
}
