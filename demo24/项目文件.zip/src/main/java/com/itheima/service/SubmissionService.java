package com.itheima.service;

import com.itheima.pojo.Submission;

import java.util.List;

public interface SubmissionService {
    List<Submission> getAllSubmissions();

    Submission getSubmissions(Integer id);

    Submission addSubmission(Submission submission);

    Submission updateSubmission(Submission submission);

    void deleteSubmission(Integer id);

    List<Submission> addSubmissions(List<Submission> submissions);
}
