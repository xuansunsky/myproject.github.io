package com.itheima.service;

import com.itheima.pojo.Role;

import java.util.List;

public interface RoleService {


    List<Role> getAllRoles();

    Role addRole(Role role);

    Role updateRole(Role role);

    void deleteRole(int roleId);
}
