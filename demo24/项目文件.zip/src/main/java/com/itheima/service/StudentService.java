package com.itheima.service;

import com.itheima.pojo.PageBean;
import com.itheima.pojo.Student;

import java.util.List;

public interface StudentService {
    void add(Student student);


    void update(Student student);

    void delete(Integer id);

    List<Student> getstudent(Integer number, String state);

    PageBean<Student> list(Integer pageNum, Integer pageSize, Integer collegeId, String state, String grade, String studentclass, String major);

    List<Student> export(Integer categoryId, String state, String grade, String studentclass, String major);

    void addmany(List<Student> students);
}
