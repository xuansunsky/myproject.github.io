package com.itheima.service;


import com.itheima.mapper.MajorMapper;
import com.itheima.pojo.Major;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MajorServiceImpl implements MajorService{
    @Autowired
    private MajorMapper majorMapper;
    @Override
    public List<Major> get(Integer id) {

        return majorMapper.get(id);
    }

    @Override
    public Major createMajor(Major major) {
        majorMapper.insert(major);
        return major;
    }

    @Override
    public Major updateMajor( Major major) {

        majorMapper.update(major);
        return major;
    }

    @Override
    public void deleteMajor(Integer id) {
        majorMapper.delete(id);
    }
}
