package com.itheima.service;

import com.itheima.mapper.RoleMapper;
import com.itheima.pojo.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceimpl implements RoleService{
   @Autowired
private RoleMapper roleMapper;


    @Override
    public List<Role> getAllRoles() {
        return roleMapper.list();
    }

    @Override
    public Role addRole(Role role) {
         roleMapper.add(role);
         return role;
    }

    @Override
    public Role updateRole(Role role) {
        roleMapper.update(role);
        return role;
    }


    @Override
    public void deleteRole(int roleId) {
     roleMapper.delete(roleId);
    }
}
