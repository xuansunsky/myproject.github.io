package com.itheima.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.itheima.mapper.StudentMapper;
import com.itheima.pojo.PageBean;
import com.itheima.pojo.Student;
import com.itheima.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Service

public class StudentServiceImpl implements StudentService {
   @Autowired
    private StudentMapper studentMapper;
    @Override
    public void add(Student student) {
        student.setCreateTime(LocalDateTime.now());
        student.setUpdateTime(LocalDateTime.now());
        Map<String,Object> map= ThreadLocalUtil.get();
        Integer userid=(Integer) map.get("id");
        student.setCreateUser(userid);
        studentMapper.add(student);

    }



    @Override
    public void update(Student student) {

        student.setUpdateTime(LocalDateTime.now());
        studentMapper.update(student);

    }

    @Override
    public void delete(Integer id) {
        studentMapper.delete(id);
    }

    @Override
    public List<Student> getstudent(Integer number, String state) {
        Map<String,Object> map=ThreadLocalUtil.get();
        Integer id=(Integer) map.get("id");
        return studentMapper.getstudent(number,state);
    }

    @Override
    public PageBean<Student> list(Integer pageNum, Integer pageSize, Integer categoryId, String state, String grade, String studentclass, String major) {
        PageBean<Student> pageBean=new PageBean<>();

        PageHelper.startPage(pageNum,pageSize);

        Map<String,Object> map=ThreadLocalUtil.get();
        Integer userid=(Integer) map.get("id");
        List<Student> as= studentMapper.list(userid,categoryId,state,grade,studentclass,major);
        Page<Student> p=(Page<Student>) as;
        pageBean.setTotal(p.getTotal());
        pageBean.setItems(p.getResult());
        return pageBean;
    }

    @Override
    public List<Student> export(Integer categoryId, String state, String grade, String studentclass, String major) {
        Map<String,Object> map=ThreadLocalUtil.get();
        Integer userid=(Integer) map.get("id");
        List<Student> as= studentMapper.list(userid,categoryId,state,grade,studentclass,major);
        return as;
    }

    @Override
    public void addmany(List<Student> students) {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userId = (Integer) map.get("id");

        // 当前时间
        LocalDateTime now = LocalDateTime.now();

        // 遍历文章列表，为每篇文章设置创建时间、更新时间和创建者
        for (Student student : students) {
            student.setCreateTime(now);
            student.setUpdateTime(now);
            student.setCreateUser(userId);
            // 添加文章到数据库
            studentMapper.add(student);
        }

    }
}
