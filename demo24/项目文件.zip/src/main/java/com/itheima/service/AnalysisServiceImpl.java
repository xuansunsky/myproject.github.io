package com.itheima.service;

import com.itheima.mapper.AnalysisMapper;
import com.itheima.pojo.StudentAnalysis;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AnalysisServiceImpl implements AnalysisService {
@Autowired
    AnalysisMapper analysisMapper;
    @Override
    public void add(StudentAnalysis studentAnalysis) {
       analysisMapper.add(studentAnalysis);

    }

    @Override
    public StudentAnalysis getstate(Integer sid) {
        return analysisMapper.getstate(sid);
    }

    @Override
    public StudentAnalysis get(Integer id) {

        return analysisMapper.get(id);
    }

    @Override
    public void update(Integer id) {
   analysisMapper.update(id);
    }

    @Override
    public void delete(Integer id) {
    analysisMapper.delete(id);
    }
}
