package com.itheima.service;

import com.itheima.mapper.ReportMapper;
import com.itheima.pojo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportServiceImpl implements ReportService{
@Autowired
    ReportMapper reportMapper;

    @Override
    public Report createReport(Report report) {
       reportMapper.add(report);
       return report;

    }

    @Override
    public List<Avgclass> banji() {
       System.out.println(reportMapper.banji());
        return reportMapper.banji();
    }

    @Override
    public List<Avgstudent> avgstudent() {
        return reportMapper.avgstudent();
    }

    @Override
    public List<Sad> avgstudentclass(String studentclass) {
        return reportMapper.avgstudentclass(studentclass);
    }

    @Override
    public List<Findavgbeyondstudent> findavgbeyondstudent(String studentclass) {
        return reportMapper.findavgbeyondstudent(studentclass);
    }

    @Override
    public List<findunusualstudent> findunusualstudent(String studentclass) {
        return reportMapper.findunusualstudent(studentclass);
    }

    @Override
    public List<Report> findsubmittrends(String studentid, String course) {
        return reportMapper.findsubmittrends(studentid,course);
    }

}
