package com.itheima.service;

import com.itheima.mapper.SubmissionMapper;
import com.itheima.pojo.Submission;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubmissionServiceImpl implements SubmissionService{
    @Autowired
    SubmissionMapper submissionMapper;

    @Override
    public List<Submission> getAllSubmissions() {
        // 调用Mapper/DAO层方法获取所有提交记录
        return submissionMapper.selectAllSubmissions();
    }
    @Override
    public Submission getSubmissions(Integer id) {
        // 调用Mapper/DAO层方法根据id获取特定的提交记录
        return submissionMapper.selectSubmissionById(id);
    }

    @Override
    public Submission addSubmission(Submission submission) {
        // 先插入数据
        submissionMapper.insertSubmission(submission);
        // 插入后，MyBatis可以帮助我们获取到自增的id
        // 返回包含id的submission对象
        return submission;
    }

    @Override
    public Submission updateSubmission(Submission submission) {
        // 更新数据，这里假设你的mapper已经处理好了更新逻辑
        submissionMapper.updateSubmission(submission);
        // 更新成功后，返回更新的对象
        return submission;
    }

    @Override
    public void deleteSubmission(Integer id) {
        // 调用Mapper/DAO层方法删除指定id的提交记录
        submissionMapper.deleteSubmission(id);
    }

    @Override
    public List<Submission> addSubmissions(List<Submission> submissions) {
       for(Submission submission:submissions)
       {
           submissionMapper.insertSubmission(submission);
       }


        return submissions;
    }


}
