package com.itheima.service;

import com.itheima.pojo.College;

import java.util.List;

public interface CollegeService {
    College getColleges(Integer id);

    College createCollege(College college);

    College updateCollege(College college);

    void deleteCollege(Integer id);

    List<College> getallcolleges();
}
