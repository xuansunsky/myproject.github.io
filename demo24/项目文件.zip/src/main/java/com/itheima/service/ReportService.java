package com.itheima.service;

import com.itheima.pojo.*;

import java.util.List;

public interface ReportService {
    Report createReport(Report report);

    List<Avgclass> banji();

    List<Avgstudent> avgstudent();

    List<Sad> avgstudentclass(String studentclass);

    List<Findavgbeyondstudent> findavgbeyondstudent(String studentclass);

    List<findunusualstudent> findunusualstudent(String studentclass);

    List<Report> findsubmittrends(String studentid, String course);
}
