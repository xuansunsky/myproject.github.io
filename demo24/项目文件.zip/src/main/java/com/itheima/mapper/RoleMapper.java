package com.itheima.mapper;

import com.itheima.pojo.Role;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface RoleMapper {

    @Insert("INSERT INTO role(id, role) VALUES(#{id}, #{role})")
    void add(Role role);

    @Select("SELECT * FROM role WHERE id = #{id}")
    Role findById(Integer id);

    @Select("SELECT * FROM role")
    List<Role> list();

    @Update("UPDATE role SET role = #{role} WHERE id = #{id}")
    void update(Role role);

    @Delete("DELETE FROM role WHERE id = #{id}")
    void delete(Integer id);
}
