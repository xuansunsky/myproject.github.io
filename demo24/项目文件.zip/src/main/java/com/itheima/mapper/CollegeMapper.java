package com.itheima.mapper;

import com.itheima.pojo.College;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CollegeMapper {
    @Select("select * from colleges")
     List<College> getallcollege();

    @Select("SELECT * FROM colleges where college_id=#{id}")
    College getColleges(Integer id);

    @Insert("INSERT INTO colleges (name) VALUES (#{name})")
    void insert(College college);

    @Update("UPDATE colleges SET name = #{name} WHERE college_id = #{id}")
    void update(College college);

    @Delete("DELETE FROM colleges WHERE college_id = #{id}")
    void delete(Integer id);
}
