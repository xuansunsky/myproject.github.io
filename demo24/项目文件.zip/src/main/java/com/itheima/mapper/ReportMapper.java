package com.itheima.mapper;


import com.itheima.pojo.*;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ReportMapper {
    @Insert("INSERT INTO student_reports (student_id, student_name, grade, class, course, report_submission_date, report_due_date) VALUES (#{studentId}, #{studentName}, #{grade}, #{studentClass}, #{course}, #{reportSubmissionDate}, #{reportDueDate})")
    void add(Report report);

    @Select("SELECT class as studentClass, SUM(qwe) AS averageDelay \n" +
            "FROM (\n" +
            "    SELECT class, \n" +
            "           CASE \n" +
            "               WHEN report_submission_date > report_due_date THEN 1 \n" +
            "               ELSE 0 \n" +
            "           END AS qwe\n" +
            "    FROM student_reports \n" +
            ") subquery \n" +
            "GROUP BY class")
    List<Avgclass> banji();
    @Select("SELECT class AS student, " +
            "SUM(CASE WHEN report_submission_date > report_due_date THEN 1 ELSE 0 END) / COUNT(DISTINCT student_id) AS studentAvgDelay " +
            "FROM student_reports " +
            "GROUP BY class")
    List<Avgstudent> avgstudent();
    @Select("SELECT class AS string, " +
            "SUM(CASE WHEN report_submission_date > report_due_date THEN 1 ELSE 0 END) / COUNT(DISTINCT student_id) AS adouble " +
            "FROM student_reports " +
            "WHERE course=#{course} " +
            "GROUP BY class")
    List<Sad> avgstudentclass(String course);
    @Select("WITH ClassAverage AS (\n" +
            "    SELECT class,\n" +
            "           SUM(CASE WHEN report_submission_date > report_due_date THEN 1 ELSE 0 END) * 1.0 / COUNT(DISTINCT student_id) AS avg_late_submissions\n" +
            "    FROM student_reports\n" +
            "    WHERE course=#{course}\n" +
            "    GROUP BY class\n" +
            ")\n" +
            "-- 使用修改后的查询语句\n" +
            "SELECT sr.student_id, sr.class as studuentclass,sr.student_name, sr.course, COUNT(*) AS late_submissions , ca.avg_late_submissions\n" +
            "FROM student_reports sr\n" +
            "JOIN ClassAverage ca ON sr.class = ca.class\n" +
            "WHERE sr.report_submission_date > sr.report_due_date and course=#{course}\n" +
            "GROUP BY sr.student_id,sr.student_name, sr.class, sr.course\n" +
            "HAVING COUNT(*) > ca.avg_late_submissions"
    )
    List<Findavgbeyondstudent> findavgbeyondstudent(String course);
    @Select("WITH DateExtremes AS (\n" +
            "  SELECT\n" +
            "    course,\n" +
            "    MIN(report_submission_date) AS start_date,\n" +
            "    MAX(report_submission_date) AS end_date\n" +
            "  FROM\n" +
            "    student_reports\n" +
            "  GROUP BY\n" +
            "    course\n" +
            "),\n" +
            "MidPoints AS (\n" +
            "  SELECT\n" +
            "    course,\n" +
            "    start_date,\n" +
            "    end_date,\n" +
            "    start_date + INTERVAL (TIMESTAMPDIFF(DAY, start_date, end_date) DIV 2) DAY AS midpoint\n" +
            "  FROM\n" +
            "    DateExtremes\n" +
            ")\n" +
            "SELECT\n" +
            "  sr.student_id,\n" +
            "  sr.course,\n" +
            "  SUM(CASE WHEN report_submission_date <= m.midpoint AND report_submission_date > report_due_date THEN 1 ELSE 0 END) AS early_late_submissions,\n" +
            "  SUM(CASE WHEN report_submission_date > m.midpoint AND report_submission_date > report_due_date THEN 1 ELSE 0 END) AS late_late_submissions\n" +
            "FROM\n" +
            "  student_reports sr\n" +
            "JOIN\n" +
            "  MidPoints m ON sr.course = m.course\n" +
            "where sr.course=#{course}"+
            "GROUP BY\n" +
            "  sr.student_id \n" +
            "HAVING\n" +
            "  early_late_submissions < late_late_submissions;")
    List<findunusualstudent> findunusualstudent(String course);
    @Select("select * " +
            "from student_reports " +
            "where student_id=#{studentid} and course=#{course} ")
    List<Report> findsubmittrends(String studentid,String course);



}
