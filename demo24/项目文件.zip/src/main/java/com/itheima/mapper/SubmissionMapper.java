package com.itheima.mapper;

import com.itheima.pojo.Submission;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface SubmissionMapper {

    @Select("SELECT * FROM reportsubmissiontable")
    List<Submission> selectAllSubmissions();

    @Select("SELECT * FROM reportsubmissiontable WHERE id = #{id}")
    Submission selectSubmissionById(Integer id);

    @Insert("INSERT INTO reportsubmissiontable (student_number, submission_date, deadline) " +
            "VALUES (#{studentNumber}, #{submissionDate}, #{deadline})")
    void insertSubmission(Submission submission);

    @Update("UPDATE reportsubmissiontable " +
            "SET student_number = #{studentNumber}, submission_date = #{submissionDate}, deadline = #{deadline}, status = #{status}, score = #{score} " +
            "WHERE id = #{id}")
    void updateSubmission(Submission submission);

    @Delete("DELETE FROM reportsubmissiontable WHERE id = #{id}")
    void deleteSubmission(Integer id);
}
