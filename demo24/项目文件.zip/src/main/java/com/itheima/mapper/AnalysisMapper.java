package com.itheima.mapper;

import com.itheima.pojo.StudentAnalysis;
import org.apache.ibatis.annotations.*;

@Mapper
public interface AnalysisMapper {
    @Insert("insert into student_analysis(  学习状态分析, 消费习惯分析, 社交活动参与度分析, 心理状况分析, 所属人)"+" values(#{学习状态分析},#{消费习惯分析},#{社交活动参与度分析},#{心理状况分析},#{所属人})")
            void add(StudentAnalysis studentAnalysis);
    @Select("SELECT id, 学习状态分析, 消费习惯分析, 社交活动参与度分析, 心理状况分析 FROM student_analysis WHERE id = #{id}")
    StudentAnalysis get(Integer id);
    @Select("SELECT id, 学习状态分析, 消费习惯分析, 社交活动参与度分析, 心理状况分析, 所属人 FROM student_analysis WHERE 所属人 = #{sid}")
    StudentAnalysis getstate(Integer sid);
    @Update("UPDATE student_analysis SET 学习状态分析 = #{学习状态分析}, 消费习惯分析 = #{消费习惯分析}, 社交活动参与度分析 = #{社交活动参与度分析}, 心理状况分析 = #{心理状况分析} WHERE id = #{id}")
    void update(Integer id);
    @Delete("DELETE FROM student_analysis WHERE id = #{id}")
    void delete(Integer id);

}
