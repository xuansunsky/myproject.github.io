package com.itheima.mapper;

import com.itheima.pojo.Major;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface MajorMapper {
    @Select("select * from majors where college_id=#{id}")
    List<Major> get(Integer id);
    @Insert("INSERT INTO majors (majorname, college_id) VALUES (#{name}, #{collegeId})")
    void update(Major major);
    @Update("UPDATE majors SET majorname = #{name}, college_id = #{collegeId} WHERE id = #{id}")
    void insert(Major major);
    @Delete("DELETE FROM majors WHERE major_id = #{id}")
    void delete(Integer id);
}
