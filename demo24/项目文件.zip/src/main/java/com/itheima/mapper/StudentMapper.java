package com.itheima.mapper;

import com.itheima.pojo.Student;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface StudentMapper {
    @Insert("insert into student(name,content,cover_img,state,college_id,create_user,create_time, update_time, grade, studentclass, major)"
    +" values(#{name},#{content},#{coverImg},#{state},#{collegeId},#{createUser},#{createTime},#{updateTime},#{grade},#{studentclass},#{major})")
       void add(Student student);
    @Select("Select * from student where college_id=#{categoryid} and state=#{state}")
    List<Student> getstudent(Integer categoryid, String state);



    @Update("update student set name = #{name},college_id=#{categoryId}, content = #{content}, cover_img = #{coverImg}, state = #{state}, update_time = #{updateTime} where id = #{id}")
    void update(Student student);
    @Delete("delete from student where id=#{id}")
    void delete(Integer id);


    List<Student> list(Integer userid, Integer collegeId, String state, String grade, String studentclass, String major);
}
