package com.itheima.controller;

import com.itheima.pojo.College;
import com.itheima.pojo.Result;
import com.itheima.service.CollegeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/colleges")
public class CollegeController {

    @Autowired
    private CollegeService collegeService;
@GetMapping("/all")
public Result<List<College>> getAllColleges()
{ List<College> a=collegeService.getallcolleges();
    return Result.success(a);
}
    // 获取所有学院列表
    @GetMapping
    public Result<College> getCollege(Integer id) {
        College colleges = collegeService.getColleges(id);
        return Result.success(colleges);
    }

    // 创建新学院
    @PostMapping
    public Result<College> createCollege(@RequestBody College college) {
        College createdCollege = collegeService.createCollege(college);
        return Result.success(createdCollege);
    }

    // 更新学院信息
    @PutMapping
    public Result<College> updateCollege(@RequestBody College college) {
        College updatedCollege = collegeService.updateCollege(college);
        return Result.success(updatedCollege);
    }

    // 删除学院
    @DeleteMapping
    public Result<?> deleteCollege(@PathVariable Integer id) {
        collegeService.deleteCollege(id);
        return Result.success();
    }
}
