package com.itheima.controller;

import com.itheima.pojo.Category;
import com.itheima.pojo.Result;
import com.itheima.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/category")
public class CategoryController {
@Autowired
private CategoryService categoryService;
    @PostMapping
    public Result add(@RequestBody  Category category)
    {
categoryService.add(category);
return Result.success();

    }
    @GetMapping
    public Result<List<Category>> list()
    {
      List<Category> cs=categoryService.list();
      return Result.success(cs);
    }

    @GetMapping("/detail")
    public Result<Category> detail(Integer id)
    {
       Category c= categoryService.findById(id);
       return Result.success(c);
    }
    @PutMapping
    public Result update(@RequestBody  Category category)
    {
        categoryService.update(category);
        return Result.success(category);
    }
    @DeleteMapping
    public Result delete(@RequestParam(value = "id") Integer id)
    {   categoryService.delete(id);
        return Result.success();
    }
}
