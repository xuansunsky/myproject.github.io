package com.itheima.controller;

import com.itheima.pojo.Result;
import com.itheima.pojo.Role;
import com.itheima.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/role")
public class RoleController {
    @Autowired
    private RoleService roleService;


    // 查询所有角色
    @RequestMapping("/getall")
    public Result<List<Role>> list() {
        List<Role> roles = roleService.getAllRoles();
        return Result.success(roles);
    }

    // 添加角色
    @PostMapping
    public Result<Role> add(Role role) {
        Role addedRole = roleService.addRole(role);
        return Result.success(addedRole);
    }

    // 更新角色
    @PutMapping
    public Result<Role> update(Role role) {
        Role updatedRole = roleService.updateRole(role);
        return Result.success(updatedRole);
    }

    // 删除角色
    @DeleteMapping
    public Result<String> delete(int roleId) {
        roleService.deleteRole(roleId);
        return Result.success();
    }
}
