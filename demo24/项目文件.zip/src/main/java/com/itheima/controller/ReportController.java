package com.itheima.controller;


import com.itheima.pojo.*;
import com.itheima.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/report")
public class ReportController {
    @Autowired
    ReportService reportService;
    @PostMapping
    public Result<Report> createReport(@RequestBody Report report)
    {     Report report1 = reportService.createReport(report);
        return Result.success(report1);

    }
    @PostMapping("/createreports")
    public Result<List<Report>> createReports(@RequestBody List<Report> reports)
    {
        List<Report> savedReports = new ArrayList<>();
        for (Report report : reports) {
            Report savedReport = reportService.createReport(report);
            savedReports.add(savedReport);
        }
        return Result.success(savedReports);

    }
    @GetMapping("/everybanji")
    public Result<List<Avgclass>> banji()
    {
        List<Avgclass> a= reportService.banji();
        return Result.success(a);
    }
    @GetMapping("/avgstudent")
    public Result<List<Avgstudent>> avgstudent()
    {
        List<Avgstudent> a=reportService.avgstudent();
        return Result.success(a);
    }
    @GetMapping("/avgstudentclass")
    public Result<List<Sad>> avgstudentclass(String course)
    {
        List<Sad> a=reportService.avgstudentclass(course);
        return Result.success(a);

    }
    @GetMapping("/findavgbeyondstudent")
    public Result<List<Findavgbeyondstudent>> findavgbeyondstudent(String course)
    {
        List<Findavgbeyondstudent> a=reportService.findavgbeyondstudent(course);
        return Result.success(a);
    }
    @GetMapping("/findunusualstudent")
    public Result<List<findunusualstudent>> findunusualstudent(String course)
    {
        List<findunusualstudent> a=reportService.findunusualstudent(course);
        return Result.success(a);
    }
    @GetMapping("/findsubmittrends")
    public Result<List<Report>> findsubmittrends(String studentid,String course)
    {
        List<Report> a=reportService.findsubmittrends(studentid,course);
        return Result.success(a);
    }






}
