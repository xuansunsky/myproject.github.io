package com.itheima.controller;

import com.itheima.pojo.Major;
import com.itheima.pojo.Result;
import com.itheima.service.MajorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/major")
public class MajorController {
  @Autowired
private MajorService majorService;
@GetMapping
    public Result<List<Major>> get(Integer id)
{

         List<Major> a=  majorService.get(id);
    return  Result.success(a);
}
    // 创建新专业
    @PostMapping
    public Result<Major> createMajor(@RequestBody Major major) {
        Major createdMajor = majorService.createMajor(major);
        return Result.success(createdMajor);
    }

    // 更新专业信息
    @PutMapping
    public Result<Major> updateMajor(@RequestBody Major major) {
        Major updatedMajor = majorService.updateMajor(major);
        return Result.success();
    }

    // 删除专业
    @DeleteMapping
    public Result<?> deleteMajor(@PathVariable Integer id) {
        majorService.deleteMajor(id);
        return Result.success();
    }
}
