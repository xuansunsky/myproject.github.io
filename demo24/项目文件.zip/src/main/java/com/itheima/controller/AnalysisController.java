package com.itheima.controller;

import com.itheima.pojo.Result;
import com.itheima.pojo.StudentAnalysis;
import com.itheima.service.AnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/analysis")
public class AnalysisController {
    @Autowired
   private AnalysisService analysisService;
    @PostMapping
    public Result add(@RequestBody StudentAnalysis studentAnalysis)
    {
        analysisService.add(studentAnalysis);
        return Result.success();
    }
    @GetMapping
    public Result<StudentAnalysis> get(Integer id)
    {StudentAnalysis a=analysisService.get(id);
        return Result.success(a);

    }
    @GetMapping("/state")
    public Result<StudentAnalysis> getstate(Integer sid)
    {StudentAnalysis a=analysisService.getstate(sid);
        return Result.success(a);

    }
    @PutMapping
    public Result update(Integer id)
    {   analysisService.update(id);
        return Result.success();
    }
    @DeleteMapping
    public Result delete(Integer id)
    {
        analysisService.delete(id);
        return Result.success();
    }
}
