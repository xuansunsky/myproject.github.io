package com.itheima.controller;


import com.itheima.pojo.Result;
import com.itheima.pojo.Submission;
import com.itheima.service.SubmissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/submission")
public class SubmissionController {
    @Autowired
    private SubmissionService submissionService;
   @PostMapping("/many")
   public Result<List<Submission>> addSubmissions(@RequestBody List<Submission> submissions)
   { List<Submission> a = submissionService.addSubmissions(submissions);
       return Result.success(a);


   }
    // 查询所有提交记录
    @GetMapping("/getall")
    public Result<List<Submission>> listSubmissions() {
        List<Submission> submissions = submissionService.getAllSubmissions();
        return Result.success(submissions);
    }
    @GetMapping
    public Result<Submission> getSubmission(Integer id)
    { Submission submission=submissionService.getSubmissions(id);
        return Result.success(submission);

    }

    // 添加提交记录
    @PostMapping
    public Result<Submission> addSubmission(@RequestBody Submission submission) {
        Submission addedSubmission = submissionService.addSubmission(submission);
        return Result.success(addedSubmission);
    }

    // 更新提交记录
    @PutMapping
    public Result<Submission> updateSubmission(@RequestBody Submission submission) {
        Submission updatedSubmission = submissionService.updateSubmission(submission);
        return Result.success(updatedSubmission);
    }

    // 删除提交记录
    @DeleteMapping
    public Result<String> deleteSubmission(@RequestParam(value = "id") Integer id) {
        submissionService.deleteSubmission(id);
        return Result.success();
    }
}