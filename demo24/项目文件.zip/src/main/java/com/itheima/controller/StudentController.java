package com.itheima.controller;

import com.itheima.pojo.PageBean;
import com.itheima.pojo.Result;
import com.itheima.pojo.Student;
import com.itheima.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/article")
public class StudentController {
    @Autowired
    private StudentService studentService;
@PostMapping
  public Result add(@RequestBody Student student)
    {
studentService.add(student);
return Result.success();
    }

    @PostMapping("/many")
    public Result AddMany(@RequestBody List<Student> students)
    {
        studentService.addmany(students);
        return Result.success();
    }
    @GetMapping
    public Result<PageBean<Student>> list(
            Integer pageNum,
            Integer pageSize,
       @RequestParam(required = false)Integer collegeId,
            @RequestParam(required = false)String state,
            @RequestParam(required = false)String grade,
            @RequestParam(required = false)String studentclass,
            @RequestParam(required = false)String major

    )
    {
       PageBean<Student> pageBean = studentService.list(pageNum,pageSize,collegeId,state,grade,studentclass,major);
       return Result.success(pageBean);
    }





    @GetMapping("/export")
    public Result<List<Student>> export(

            @RequestParam(required = false)Integer categoryId,
            @RequestParam(required = false)String state,
            @RequestParam(required = false)String grade,
            @RequestParam(required = false)String studentclass,
            @RequestParam(required = false)String major

    )
    {
      List<Student> a= studentService.export(categoryId,state,grade,studentclass,major);

        return Result.success(a);
    }


    @GetMapping("/student")
    public Result<Integer> getstudent(Integer number,String state)
    {
        List<Student> a= studentService.getstudent(number,state);
        int count = 0;
        for (Student student : a) {
            if ("异常".equals(student.getState())) {
                count++;
            }
        }
        return Result.success(count);






    }
    @PutMapping
    public Result update(@RequestBody Student student)
    {
        studentService.update(student);
        return Result.success(student);

    }

    @DeleteMapping
    public Result delete(@RequestParam(value = "id") Integer id)
    {   studentService.delete(id);
        return Result.success();
    }


}
