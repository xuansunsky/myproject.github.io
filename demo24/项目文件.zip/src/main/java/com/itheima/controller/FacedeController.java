package com.itheima.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class FacedeController {

    @PostMapping("/f")
    public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("文件未上传");
        }

        // 这里只是为了演示，实际上你可能需要将文件保存到服务器上的某个位置
        String fileName = file.getOriginalFilename();

        // 返回上传文件的名称，确认文件已成功接收
        return ResponseEntity.ok("成功接收文件: " + fileName);
    }
}
