package com.itheima.pojo;

import lombok.Data;

@Data
public class Role {
    int id;
    String role;

}
