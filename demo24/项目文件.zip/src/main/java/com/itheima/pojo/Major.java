package com.itheima.pojo;

import lombok.Data;

@Data
public class Major {
    private Long majorid;

    private String majorname;
    private String collegeid;
}
