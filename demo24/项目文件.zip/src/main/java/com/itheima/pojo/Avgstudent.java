package com.itheima.pojo;

import lombok.Data;

@Data
public class Avgstudent {
    private String student;
    private double studentAvgDelay;
}
