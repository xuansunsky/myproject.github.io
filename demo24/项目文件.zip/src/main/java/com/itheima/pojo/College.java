package com.itheima.pojo;

import lombok.Data;

@Data
public class College {
    private Integer CollegeId;
    private String CollegeName;
}
