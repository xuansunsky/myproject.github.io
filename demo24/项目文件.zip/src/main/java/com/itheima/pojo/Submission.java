package com.itheima.pojo;

import lombok.Data;

import java.util.Date;

@Data
public class Submission {
    private Integer id;
    private String studentNumber;    // 学生学号// 学生名字
    private Date submissionDate; // 提交日期
    private Date deadline;
    private int status;
}
