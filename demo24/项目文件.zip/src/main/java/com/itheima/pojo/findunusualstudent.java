package com.itheima.pojo;

import lombok.Data;

@Data
public class findunusualstudent {
    String studentid;
    String course;
    int earlylatesubmissions;
    int latelatesubmissions;
}
