package com.itheima.pojo;

import lombok.Data;

import java.util.Date;

@Data
public class Report {
    private int id;
    private String studentId;
    private String studentName;
    private String grade;
    private String CLass;
    private String course;
    private Date reportSubmissionDate;
    private Date reportDueDate;
}
