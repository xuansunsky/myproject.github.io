package com.itheima.pojo;

import lombok.Data;
@Data

public class studentnumber {
    int number;
    String state;

}
