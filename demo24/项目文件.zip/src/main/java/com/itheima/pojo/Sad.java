package com.itheima.pojo;

import lombok.Data;

@Data
public class Sad {
    private String string;
    private Double aDouble;

}
