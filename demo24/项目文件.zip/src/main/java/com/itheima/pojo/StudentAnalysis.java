package com.itheima.pojo;

import lombok.Data;

@Data
public class StudentAnalysis {

    private Integer id;

    private String 学习状态分析;
    private String 消费习惯分析;
    private String 社交活动参与度分析;
    private String 心理状况分析;
    private int 所属人;

    // 构造器、getter和setter省略
}