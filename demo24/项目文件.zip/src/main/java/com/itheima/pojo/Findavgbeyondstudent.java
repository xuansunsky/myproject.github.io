package com.itheima.pojo;

import lombok.Data;

@Data
public class Findavgbeyondstudent {
    String studentid;
    String studuentclass;
    String studentname;
    String course;
    int latesubmissions;
    double avglatesubmissions;

}
