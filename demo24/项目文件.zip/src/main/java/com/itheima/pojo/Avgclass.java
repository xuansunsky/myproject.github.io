package com.itheima.pojo;

import lombok.Data;

@Data
public class Avgclass {
    private String studentClass;
    private double averageDelay;

}
