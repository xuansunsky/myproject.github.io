package com.itheima.pojo;

import lombok.Data;

@Data
public class Face {
    String a;
    String b;
}
